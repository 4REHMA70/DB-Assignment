

const express = require('express');
const router = express.Router();
const ctrlBoqs = require('../controllers/boqs');
const ctrlLevel1s = require('../controllers/level1s');
//boqs
router
    .route('/boqs')
    .get(ctrlBoqs.boqsList)
    .post(ctrlBoqs.boqsCreate);
router
    .route('/boqs/:boqid')
    .get(ctrlBoqs.boqsReadOne)
    .put(ctrlBoqs.boqsUpdateOne)
    .delete(ctrlBoqs.boqsDeleteOne);
//level1s
router
    .route('/boqs/:boqid/level1s')
    .post(ctrlLevel1s.level1sCreate);
router
    .route('/boqs/:boqid/level1s/:level1id')
    .get(ctrlLevel1s.level1sReadOne)
    .put(ctrlLevel1s.level1sUpdateOne)
    .delete(ctrlLevel1s.level1sDeleteOne);
module.exports = router;