const mongoose = require('mongoose');
const level1sSchema = new mongoose.Schema({
    product: {
        type: String,
        required: true
    },
    description: {
        type: String,
        required: true
    },
    category: {
        type: String,
        required: true
    },
    price: {
        type: Number,
        default: 0
    },
    quantity: {
        type: Number,
        default: 1,
        min: 1
    },
    discount: {
        type: Number,
        default: 0,
        min: 0,
        max: 1
    }

});
const boqSchema = new mongoose.Schema({
    boqName: {
        type: String,
        required: true
    },
    supplierName: {
        type: String,
        required: true
    },
    date: {
        type: Date,
        required: true
    },
    discount: {
        type: Number,
        default: 0,
        min: 0,
        max: 1
    },
    level1s : [level1sSchema]
});

mongoose.model('Boq', boqSchema);