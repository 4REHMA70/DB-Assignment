const mongoose = require('mongoose').set('debug', true);
const ModelBoq = mongoose.model('Boq');

const doAddLevel1 = (req, res, boq) => {
    if (!boq) {
        res.status(404).json({
            "message": "Boq not found"
        });
    } else {
        const {
            product,
            description,
            category,
            price,
            quantity,
            discount

        } = req.body;
        boq.level1s.push({
            product,
            description,
            category,
            price,
            quantity,
            discount
        });
        boq.save((err, boq) => {
            if (err) {
                res.status(400).json(err);
            } else {
                const thisLevel1 = boq.level1s.slice(-1).pop();
                res.status(201).json(thisLevel1);
            }
        });
    }
};


const level1sCreate = (req, res) => {
    const boqId = req.params.boqid;
    if (boqId) {
        ModelBoq
            .findById(boqId)
            .select('level1s')
            .exec((err, boq) => {
                if (err) {
                    res
                        .status(400)
                        .json(err);
                } else {
                    doAddLevel1(req, res, boq);
                }
            });
    } else {
        res
            .status(404)
            .json({
                "message": "boq not found"
            });
    }
};
const level1sReadOne = (req, res) => {
    ModelBoq
        .findById(req.params.boqid)
        .select('name level1s')
        .exec((err, boq) => {
            if (!boq) {
                return res
                    .status(404)
                    .json({
                        "message": "boq not found"
                    });
            } else if (err) {
                return res
                    .status(400)
                    .json(err);
            }

            console.log(boq);
            if (boq.level1s && boq.level1s.length > 0) {
                const level1 = boq.level1s.id(req.params.level1id);

                if (!level1) {
                    return res
                        .status(404)
                        .json({
                            "message": "level1 not found"
                        });
                } else {
                    const response = {
                        boq: {
                            name: boq.name,
                            id: req.params.boqid
                        },
                        level1
                    };

                    return res
                        .status(200)
                        .json(response);
                }
            } else {
                return res
                    .status(404)
                    .json({
                        "message": "No level1s found"
                    });
            }
        });
};

const level1sUpdateOne = (req, res) => {
    if (!req.params.boqid || !req.params.level1id) {
        return res.status(404).json({
            "message": "Not found, boqid and level1id are both required"
        });
    }
    ModelBoq.findById(req.params.boqid).select('level1s').exec((err, boq) => {
        if (!boq) {
            return res.status(404).json({
                "message": "boq not found"
            });
        } else if (err) {
            return res.status(400).json(err);
        }
        if (boq.level1s && boq.level1s.length > 0) {
            const thisLevel1 = boq.level1s.id(req.params.level1id);
            if (!thisLevel1) {
                res.status(404).json({
                    "message": "level1 not found"
                });
            } else {
                //pdcpqd
                thisLevel1.product = req.body.product;
                thisLevel1.description = req.body.description;
                thisLevel1.category = req.body.category;
                thisLevel1.price = req.body.price;
                thisLevel1.quantity = req.body.quantity;
                thisLevel1.discount = req.body.discount;
                boq.save((err, boq) => {
                    if (err) {
                        res.status(404).json(err);
                    } else {
                        res.status(200).json(thisLevel1);
                    }
                });
            }
        } else {
            res.status(404).json({
                "message": "No level1 to update"
            });
        }
    });
};
const level1sDeleteOne = (req, res) => {
    const {
        boqid,
        level1id
    } = req.params;
    if (!boqid || !level1id) {
        return res.status(404).json({
            'message': 'Not found, boqid and level1id are both required'
        });
    }
    ModelBoq.findById(boqid).select('level1s').exec((err, boq) => {
        if (!boq) {
            return res.status(404).json({
                'message': 'boq not found'
            });
        } else if (err) {
            return res.status(400).json(err);
        }
        if (boq.level1s && boq.level1s.length > 0) {
            if (!boq.level1s.id(level1id)) {
                return res.status(404).json({
                    'message': 'level1 not found'
                });
            } else {
                boq.level1s.id(level1id).remove();
                boq.save(err => {
                    if (err) {
                        return res.status(404).json(err);
                    } else {
                        res.status(204).json(null);
                    }
                });
            }
        } else {
            res.status(404).json({
                'message': 'No level1 to delete'
            });
        }
    });
};


module.exports = {
    level1sCreate,
    level1sReadOne,
    level1sUpdateOne,
    level1sDeleteOne
}