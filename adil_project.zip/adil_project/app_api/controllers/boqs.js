const mongoose = require('mongoose').set('debug', true);
const ModelBoq = mongoose.model('Boq');

const boqsList = (req, res) => {
    ModelBoq
        .find()
        .exec((err, boqs) => {
            console.log(err, boqs);
            if (!boqs) {
                return res
                    .status(404)
                    .json({
                        "message": "boq not found"
                    });
            } else if (err) {
                return res
                    .status(404)
                    .json(err);
            }

            return res
                .status(200)
                .json(boqs);
        });
};
const boqsCreate = (req, res) => {
    ModelBoq.create({
        boqName: req.body.boqName,
        supplierName: req.body.supplierName,
        date: req.body.date,
    }, (err, boq) => {
        if (err) {
            res.status(400).json(err);
        } else {
            res.status(201).json(boq);
        }
    });
};
const boqsReadOne = (req, res) => {
    ModelBoq
        .findById(req.params.boqid)
        .exec((err, boq) => {
            console.log(err, boq);
            if (!boq) {
                return res
                    .status(404)
                    .json({
                        "message": "boq not found"
                    });
            } else if (err) {
                return res
                    .status(404)
                    .json(err);
            }

            return res
                .status(200)
                .json(boq);
        });
};

const boqsUpdateOne = (req, res) => {
    if (!req.params.boqid) {
        return res.status(404).json({
            "message": "Not found, boqid is required"
        });
    }
    ModelBoq
        .findById(req.params.boqid)
        .exec((err, boq) => {
            if (!boq) {
                return res
                    .json(404)
                    .status({
                        "message": "boqid not found"
                    });
            } else if (err) {
                return res
                    .status(400)
                    .json(err);
            }
            boq.boqName = req.body.boqName;
            boq.supplierName = req.body.supplierName;
            boq.date = req.body.date;
            boq.discount = req.body.discount;

            boq.save((err, loc) => {
                if (err) {
                    res
                        .status(404)
                        .json(err);
                } else {
                    res
                        .status(200)
                        .json(loc);
                }
            });
        });
};
const boqsDeleteOne = (req, res) => {
    const {
        boqid
    } = req.params;
    if (boqid) {
        ModelBoq.findByIdAndRemove(boqid).exec((err, boq) => {
            if (err) {
                return res.status(404).json(err);
            }
            res.status(204).json(null);
        });
    } else {
        res.status(404).json({
            "message": "No boq"
        });
    }
};

module.exports = {
    boqsList,
    boqsCreate,
    boqsReadOne,
    boqsUpdateOne,
    boqsDeleteOne
}