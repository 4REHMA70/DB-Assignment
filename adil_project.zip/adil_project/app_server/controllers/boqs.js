const request = require('request');
const apiOptions = {
    server: 'http://localhost:3000'
};
const renderHomepage = (req, res, responseBody) => {
    let message = null;
    if (!(responseBody instanceof Array)) {
        message = "API lookup error";
        responseBody = [];
    } else {
        if (!responseBody.length) {
            message = "No boqs found";
        }
    }
    res.render('boqs-list', {
        title: "Casco's BOQs",
        pageHeader: {
            title: 'BOQ list',
            strapline: 'Create, update, and delete BOQs!'
        },
        boqs: responseBody,
        message
    });

};

const homelist = (req, res) => {
    const path = '/api/boqs';
    const requestOptions = {
        url: `${apiOptions.server}${path}`,
        method: 'GET',
        json: {},
    };

    request(requestOptions, (err, response, body) => {

        renderHomepage(req, res, body);
    });
};

const renderBoqInfo = (req, res, boq) => {
    res.render('boq-info', {
        title: boq.boqName,
        pageHeader: {
            title: boq.boqName
        },
        boq
    });

}

const boqInfo = (req, res) => {
    const path = `/api/boqs/${req.params.boqid}`;
    const requestOptions = {
        url: `${apiOptions.server}${path}`,
        method: 'GET',
        json: {}
    };
    request(requestOptions, (err, response, body) => {
        console.log(body);
        renderBoqInfo(req, res, body);
    });
};

const addBoq = (req, res) => {
    res.render('add-boq-form', {
        title: 'Add boq',
        pageHeader: 'Add BOQ'
    });
};

const doAddBoq = (req, res) => {
    const path = `/api/boqs`;

    const postdata = {
        boqName: req.body.boqName,
        supplierName: req.params.supplierName,
        date: req.body.date
    };

    const requestOptions = {
        url: `${apiOptions.server}${path}`,
        method: 'POST',
        json: postdata
    };

    request(requestOptions, (err, response, body) => {
        console.log(postdata);
        if (response.statusCode == 201) {
            message = "Boq saved successfully"
        } else {
            message = "Error in saving boq"
        }
        res.render('add-boq-form', {
            title: 'Add boq',
            pageHeader: message
        });
    });
};

const doUpdateBoq = (req, res) => {
    const path = `/api/boqs/${req.params.boqid}`;

    boqid = req.params.boqid

    const postdata = {
        boqName: req.body.boqName,
        supplierName: req.body.supplierName,
        date: req.body.date,
        discount: req.body.discount
    };

    console.log("Inside doUpdateBoQ Setting PUT //////////////////////////");

    const requestOptions = {
        url: `${apiOptions.server}${path}`,
        method: 'PUT',
        json: postdata
    };

    request(
        requestOptions,
        (err, { statusCode }) => {
            if (statusCode === 200) {
                res.redirect(`/boq/${boqid}`);
            } else {
                //showError(req, res, statusCode);
            }
        }
    );
};


const doAddBoqLevel1 = (req, res) => {
    const boqid = req.params.boqid;
    const path = `/api/boqs/${boqid}/level1s`;
    const postdata = {
        product: req.body.product,
        description: req.body.description,
        category: req.body.category,
        price: req.body.price,
        quantity: req.body.quantity,
        discount: req.body.discount
    };

    console.log("inside doAddBoqLevel1 setting POST");
    const requestOptions = {
        url: `${apiOptions.server}${path}`,
        method: 'POST',
        json: postdata
    };
    request(
        requestOptions,
        (err, { statusCode }, body) => {
            if (statusCode === 201) {
                res.redirect(`/boq/${boqid}`);
            } else {
                res.redirect(`/boq/${boqid}`);                
            }
        }
    );
};

const addBoqLevel1 = (req, res) => {
    res.render('add-level1-form', {
        title: 'Add BoQ Level 1',
        pageHeader: 'Add BoQ Level 1'
    });
};
//product pr descrip category product price quanti discount


const deleteBoq = (req, res) => {
    const path = `/api/boqs/${req.params.boqid}`;

    boqid = req.params.boqid

    console.log("Inside deleteBoQ Setting DELETE //////////////////////////");

    const requestOptions = {
        url: `${apiOptions.server}${path}`,
        method: 'DELETE',
        json: { }
    };

    request(
        requestOptions,
        (err, { statusCode }) => {
            if (statusCode === 204) {
                res.redirect(`/`);
            } else {
                //showError(req, res, statusCode);
            }
        }
    );
}

module.exports = {
    homelist,
    boqInfo,
    addBoq,
    doAddBoq,
    doUpdateBoq,
    addBoqLevel1,
    doAddBoqLevel1,
    deleteBoq
};