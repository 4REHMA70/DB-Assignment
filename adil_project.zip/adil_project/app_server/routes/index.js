
const express = require('express');
const { post } = require('../../app');
const router = express.Router();
const ctrlBoqs = require('../controllers/boqs');
const ctrlOthers = require('../controllers/others');

router
    .route('/')
    .get(ctrlBoqs.homelist);

router
    .route('/boq/new')
    .get(ctrlBoqs.addBoq)
    .post(ctrlBoqs.doAddBoq);

router
    .route('/boq/:boqid') 
    .get(ctrlBoqs.boqInfo)
    .post(ctrlBoqs.doUpdateBoq);
    
router
    .route('/boq/:boqid/delete')    
    .get(ctrlBoqs.deleteBoq)

router
    .route('/boq/:boqid/level1/new')
    .get(ctrlBoqs.addBoqLevel1)
    .post(ctrlBoqs.doAddBoqLevel1);

router.get('/about', ctrlOthers.about);

module.exports = router;